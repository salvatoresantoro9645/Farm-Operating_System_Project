#ifndef WORKERPOOL_H_
#define WORKERPOOL_H_

//Specific to define
void workerFun(unsigned int thIndex, char* filename);

#endif